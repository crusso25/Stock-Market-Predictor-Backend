from app import app  # Assuming your Flask app is created in 'application.py'

if __name__ == "__main__":
    app.run()
